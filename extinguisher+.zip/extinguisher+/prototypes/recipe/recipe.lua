data:extend({
  {
    type = "recipe",
    name = "extinguisher",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
},
    result = "extinguisher"
  }
})
