data:extend({
  {
    type = "technology",
    name = "flamethrower",
    icon_size = 256, icon_mipmaps = 4,
    icon = "__base__/graphics/technology/flamethrower.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "flamethrower"
      },
      {
        type = "unlock-recipe",
        recipe = "flamethrower-ammo"
      },
      {
        type = "unlock-recipe",
        recipe = "flamethrower-turret"
      },
      {
        type = "unlock-recipe",
        recipe = "extinguisher"
      },
      {
        type = "unlock-recipe",
        recipe = "extinguisher-ammo"
      }

    },
    prerequisites = {"flammables", "military-science-pack"},
    unit =
    {
      count = 50,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"military-science-pack", 1}
      },
      time = 30
    },
    order = "e-c-b"

  }
})
