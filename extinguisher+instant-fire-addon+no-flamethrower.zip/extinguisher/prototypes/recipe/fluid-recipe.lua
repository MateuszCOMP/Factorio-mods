data:extend(
{
  {
    type = "recipe",
    name = "extinguisher-ammo",

    enabled = false,
    energy_required = 5,
    ingredients =
    {},
    result = "extinguisher-ammo"
  }
})
