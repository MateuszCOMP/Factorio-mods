data:extend({
  {
    type = "ammo-category",
    name = "extinguisher"
  }
})
