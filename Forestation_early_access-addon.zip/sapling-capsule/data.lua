local normalizeTreeCollision = settings.startup["sapling-capsule-normalize-collision-box"].value
if normalizeTreeCollision then
	for i, v in pairs( data.raw.tree ) do
			v.collision_box = {{-0.3, -0.3}, {0.3, 0.3}}
	end
end



require("prototypes.capsule")