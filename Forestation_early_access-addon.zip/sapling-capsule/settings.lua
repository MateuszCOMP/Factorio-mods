-- https://wiki.factorio.com/Tutorial:Mod_settings

data:extend({
	{
		type = "bool-setting",
		name = "sapling-capsule-normalize-collision-box",
		setting_type = "startup",
		default_value = false,
		-- order = "a"
	}
})